#include "Dump/Dump.h"

void StartRoutine(HINSTANCE hinstDLL)
{
    CloseHandle(CreateThread(0, 0, (LPTHREAD_START_ROUTINE)OffsetDumper::DumpRequestedOffsets, hinstDLL, 0, 0));
}

BOOL APIENTRY DllMain(HINSTANCE hinstDLL, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        DLLHandle = hinstDLL;
        DisableThreadLibraryCalls(hinstDLL);
        StartRoutine(hinstDLL);
        break;
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

