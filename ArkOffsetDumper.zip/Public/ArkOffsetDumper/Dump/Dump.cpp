#include "Dump.h"
#include "Detours/detours.h"

static int PAD_INDEX = 0;

bool OffsetDumper::Init()
{
	if (!Logger::Init() || !SDK::InitSDK()) return false;
}

bool OffsetDumper::Eject()
{
	if (!Logger::Remove()) return false;
	SDK::CleanupSDK();
	while (true)
	{
		FreeLibraryAndExitThread(LoadLibraryA("ArkOffsetDumper.dll"), 0);
		Sleep(20);
	}
}

std::string OffsetDumper::PADString()
{
	PAD_INDEX += 1;
	return std::to_string(PAD_INDEX);
}

int OffsetDumper::FindClassPropertyOffset(const char* Class, const char* Property)
{
	auto ClassPointer = SDK::Engine::UObject::FindClass(Class);
	for (SDK::Engine::UProperty* Child = (SDK::Engine::UProperty*)ClassPointer->Children; Child; Child = (SDK::Engine::UProperty*)Child->Next)
	{
		if (Child->GetName() == Property)
		{
			auto Offset = (int)Child->Offset;
			return Offset;
		}
	}
	return -1;
}

int OffsetDumper::FindFunctionOffset(const char* FunctionName)
{
	auto GameBase = (uintptr_t)GetModuleHandleA(nullptr);
	auto FunctionAddress = DetourFindFunction("ShooterGame.exe", FunctionName);
	if (FunctionAddress && GameBase)
	{
		DWORD FunctionOffset = (uintptr_t)FunctionAddress - GameBase;
		if (FunctionOffset >= 1) return FunctionOffset;
	}
	return -1;
}

void OffsetDumper::DumpClassProperty(PropertyInfo Property, PropertyInfo PreviousProperty, bool FirstProperty)
{
	std::stringstream Stream;
	std::transform(Property.OffsetString.begin(), Property.OffsetString.end(), Property.OffsetString.begin(), ::toupper);
	if (FirstProperty)
	{
		Logger::Print(std::string("unsigned char     PAD_" + OffsetDumper::PADString()).c_str());
		Logger::Print(std::string("[0x" + Property.OffsetString + std::string("];\n")).c_str());
	}
	else if (PreviousProperty.PropertyPointer)
	{
		const int PropertyDifference = (Property.PropertyOffset - PreviousProperty.PropertyOffset) - PreviousProperty.PropertyPointer->ElementSize;
		Stream << std::hex << PropertyDifference;
		std::string OffsetString = Stream.str();
		std::transform(OffsetString.begin(), OffsetString.end(), OffsetString.begin(), ::toupper);
		Logger::Print(std::string("unsigned char     PAD_" + OffsetDumper::PADString()).c_str());
		Logger::Print(std::string("[0x" + OffsetString + std::string("];\n")).c_str());
	}
	Logger::Print(Property.Type.c_str());
	Logger::Print("                        ");
	Logger::Print((Property.Name + std::string("; // 0x") + Property.OffsetString + std::string("\n")).c_str());
}

void OffsetDumper::DumpPartialClass(const char* Class, std::vector<std::string> ClassProperties, std::vector<std::string> ClassPropertyTypes)
{
	bool FirstProperty = true;
	SDK::Engine::UClass* ClassPointer = SDK::Engine::UObject::FindClass(Class);
	PropertyInfo PreviousProperty = PropertyInfo(nullptr, std::string(), std::string(), std::string(), 0, 0);
	Logger::Print("class "), Logger::Print(ClassPointer->GetName().c_str());
	Logger::Print("\n{\npublic:\n");
	for (size_t s = 0; s < ClassProperties.size(); s++)
	{
		for (SDK::Engine::UProperty* Child = (SDK::Engine::UProperty*)ClassPointer->Children; Child; Child = (SDK::Engine::UProperty*)Child->Next)
		{
			if (Child->GetName() == ClassProperties[s])
			{
				std::stringstream Stream;
				Stream << std::hex << Child->Offset;
				PropertyInfo CurrentInfo = PropertyInfo(Child, ClassProperties[s], ClassPropertyTypes[s], std::string(Stream.str()), Child->ElementSize, Child->Offset);
				OffsetDumper::DumpClassProperty(CurrentInfo, PreviousProperty, FirstProperty);
				PreviousProperty = CurrentInfo, FirstProperty = false;
			}
		}
	}
	Logger::Print("};\n\n");
}

void OffsetDumper::DumpRequestedOffsets()
{
	OffsetDumper::Init();
	OffsetDumper::DumpPartialClass("Class Engine.Actor", std::vector<std::string>{ "TargetingTeam", "CreationTime","RootComponent", "LastRenderTime", "bForceNonBlockingHits" }, std::vector<std::string>{ "int", "double", "USceneComponent*", "double", "bool" });
	//OffsetDumper::Eject();
}