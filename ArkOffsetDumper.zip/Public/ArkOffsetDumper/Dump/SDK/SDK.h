#pragma once
#include <Windows.h>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <locale>
#include <array>
#include "UE4/UE4.h"

#define GObjects_Offset								0x4262CE0
#define GNames_Offset								0x42AA3E0

namespace SDK
{
	bool InitSDK(const std::string& ModuleName, const uintptr_t GObjectsOffset, const uintptr_t GNamesOffset);
	bool InitSDK();
	void CleanupSDK();

	namespace Engine
	{
		template<class T>
		class TArray
		{
			friend struct FString;
		public:
			TArray() { Count = Max = 0; };

			T& operator[](int i) const { return Data[i]; };

			T* Data;
			int Count;
			int Max;
		};

		template<typename T>
		struct TTransArray : public TArray<T>
		{
			class UObject* Owner;
		};

		struct FNameEntry
		{
			uint32_t Index;
			uint32_t Pad;
			FNameEntry* HashNext;
			union
			{
				char AnsiName[1024];
				wchar_t WideName[1024];
			};
			const int GetIndex() const { return Index >> 1; }
			const char* GetAnsiName() const { return AnsiName; }

		};

		class TNameEntryArray
		{
		public:
			bool IsValidIndex(uint32_t index) const { return index < NumElements; }

			FNameEntry const* GetByID(uint32_t index) const { return *GetItemPtr(index); }

			FNameEntry const* const* GetItemPtr(uint32_t Index) const
			{
				const auto ChunkIndex = Index / 16384;
				const auto WithinChunkIndex = Index % 16384;
				const auto Chunk = Chunks[ChunkIndex];

				return Chunk + WithinChunkIndex;
			}

			FNameEntry** Chunks[128];
			uint32_t NumElements = 0;
			uint32_t NumChunks = 0;
		};

		class FUObjectItem
		{
		public:
			UObject* Object;
			int32_t SerialNumber;
			unsigned char pad_C1AOV13XBK[0x4];

			enum class ObjectFlags : int32_t
			{
				None = 0,
				Native = 1 << 25,
				Async = 1 << 26,
				AsyncLoading = 1 << 27,
				Unreachable = 1 << 28,
				PendingKill = 1 << 29,
				RootSet = 1 << 30,
				NoStrongReference = 1 << 31
			};
		};

		class TUObjectArray
		{
			enum
			{
				NumElementsPerChunk = 64 * 1024,
			};
		public:
			inline int32_t Num() const
			{
				return NumElements;
			}
			inline int32_t Max() const
			{
				return MaxElements;
			}
			inline bool IsValidIndex(int32_t Index) const
			{
				return Index < Num() && Index >= 0;
			}
			inline FUObjectItem* GetObjectPtr(int32_t Index) const
			{
				const int32_t ChunkIndex = Index / NumElementsPerChunk;
				const int32_t WithinChunkIndex = Index % NumElementsPerChunk;
				if (!IsValidIndex(Index)) return nullptr;
				if (ChunkIndex > NumChunks) return nullptr;
				if (Index > MaxElements) return nullptr;
				FUObjectItem* Chunk = Objects[ChunkIndex];
				if (!Chunk) return nullptr;
				return Chunk + WithinChunkIndex;
			}
			inline UObject* GetByIndex(int32_t index) const
			{
				FUObjectItem* ItemPtr = GetObjectPtr(index);
				if (!ItemPtr) return nullptr;
				return (*ItemPtr).Object;
			}
			inline FUObjectItem* GetItemByIndex(int32_t index) const
			{
				FUObjectItem* ItemPtr = GetObjectPtr(index);
				if (!ItemPtr) return nullptr;
				return ItemPtr;
			}
		private:
			FUObjectItem** Objects;
			FUObjectItem* PreAllocatedObjects;
			int32_t MaxElements;
			int32_t NumElements;
			int32_t MaxChunks;
			int32_t NumChunks;
		};

		struct FName
		{
			int ComparisonIndex = 0;
			int Number = 0;
			static inline TNameEntryArray* GNames = nullptr;
			static const char* GetNameByIDFast(int ID)
			{
				auto NameEntry = GNames->GetByID(ID);
				if (!NameEntry) return nullptr;
				return NameEntry->AnsiName;
			}
			static std::string GetNameByID(int ID)
			{
				auto NameEntry = GNames->GetByID(ID);
				if (!NameEntry) return std::string();
				return NameEntry->AnsiName;
			}
			const char* GetNameFast() const
			{
				auto NameEntry = GNames->GetByID(ComparisonIndex);
				if (!NameEntry) return nullptr;
				return NameEntry->AnsiName;
			}
			const std::string GetName() const
			{
				auto NameEntry = GNames->GetByID(ComparisonIndex);
				if (!NameEntry) return std::string();
				return NameEntry->AnsiName;
			}
			inline bool operator==(const FName& other) const
			{
				return ComparisonIndex == other.ComparisonIndex;
			}

			FName() {}
			FName(const char* nameToFind)
			{
				for (int i = 1000u; i < GNames->NumElements; i++)
				{
					auto Name = GetNameByIDFast(i);
					if (!Name) continue;
					if (strcmp(Name, nameToFind) == 0)
					{
						ComparisonIndex = i;
						return;
					}
				}
			}
		};

		class UClass;
		class UObject
		{
		public:
			static inline TUObjectArray* GObjects = nullptr;			// 0x0000
			void* VfTable;					// 0x0000
			int32_t                                 Flags;                      // 0x0008
			int32_t                                 InternalIndex;              // 0x000C
			UClass* Class;						// 0x0010
			FName                                   Name;                       // 0x0018
			UObject* Outer;                      // 0x0020

			static inline TUObjectArray& GetGlobalObjects() { return *GObjects; }

			std::string GetName() const;

			std::string GetFullName() const;

			template<typename T>
			static T* FindObject(const std::string& name)
			{
				for (int i = 0; i < GetGlobalObjects().Num(); ++i)
				{
					auto object = GetGlobalObjects().GetByIndex(i);
					if (object == nullptr) continue;
					if (object->GetFullName() == name) return static_cast<T*>(object);
				}
				return nullptr;
			}

			template<typename T>
			static T* FindObject()
			{
				auto v = T::StaticClass();
				for (int i = 0; i < UObject::GetGlobalObjects().Num(); ++i)
				{
					auto object = UObject::GetGlobalObjects().GetByIndex(i);
					if (object == nullptr) continue;
					if (object->IsA(v)) return static_cast<T*>(object);
				}
				return nullptr;
			}

			template<typename T>
			static std::vector<T*> FindObjects(const std::string& name)
			{
				std::vector<T*> ret;
				for (int i = 0; i < GetGlobalObjects().Num(); ++i)
				{
					auto object = GetGlobalObjects().GetByIndex(i);
					if (object == nullptr) continue;
					if (object->GetFullName() == name) ret.push_back(static_cast<T*>(object));
				}
				return ret;
			}

			template<typename T>
			static std::vector<T*> FindObjects()
			{
				std::vector<T*> ret;
				auto v = T::StaticClass();
				for (int i = 0; i < UObject::GetGlobalObjects().Num(); ++i)
				{
					auto object = UObject::GetGlobalObjects().GetByIndex(i);
					if (object == nullptr) continue;
					if (object->IsA(v)) ret.push_back(static_cast<T*>(object));
				}
				return ret;
			}
			static UClass* FindClass(const std::string& name)
			{
				return FindObject<UClass>(name);
			}

			template<typename T>
			static T* GetObjectCasted(std::size_t index)
			{
				return static_cast<T*>(GetGlobalObjects().GetByIndex(index));
			}

			bool IsA(UClass* cmp) const;
		};

		class UField : public UObject
		{
		public:
			class UField* Next; // 0x0028
		};

		class UProperty : public UField
		{
		public:
			unsigned char								pad_8F5a5TE4IdwQ[0x4];
			int32_t										ElementSize;				// 0x0034(0x0004)
			unsigned char								pad_8F55TE4ITQ[0xC];
			FName										RepNotifyFunc;				// 0x0044(0x0010)
			int32_t										Offset;						// 0x004C(0x0004)
		};

		class UStruct : public UField
		{
		public:
			class UStruct* SuperField;                                                // 0x0030
			class UField* Children;                                                  // 0x0038
			int32_t                                 PropertySize;                                              // 0x0040
			unsigned char                           pad_8F55TE4ITQ[0x4];
			TArray<unsigned char>					Script;													   // 0x0048
			int32_t                                 MinAlignment;                                              // 0x0058
			unsigned char                           pad_PVICHD1SYI[0x4];
			class UProperty* PropertyLink;                                              // 0x0060
			class UProperty* RefLink;                                                   // 0x0068
			class UProperty* DestructorLink;                                            // 0x0070
			class UProperty* PostConstructLink;                                         // 0x0078
			TArray<UObject*>                        ScriptAndPropertyObjectReferences;						   // 0x0080
		};

		class UFunction : public UStruct
		{
		public:
			uint32_t										   FunctionFlags;                                             // 0x0090
			uint16_t                                           RepOffset;                                                 // 0x0094
			unsigned char                                      pad_NRXEECH4MB[0x1];
			unsigned char                                      pad_DW5RJEN1QQ[0x1];
			uint16_t                                           ParmsSize;                                                 // 0x0098
			uint16_t                                           ReturnValueOffset;                                         // 0x009A
			uint16_t                                           RPCId;                                                     // 0x009C
			uint16_t                                           RPCResponseId;                                             // 0x009E
			class UProperty* FirstPropertyToInit;                                       // 0x00A0
			void* Func;                                                      // 0x00A8
		};

		class UClass : public UStruct
		{
		public:
			unsigned char                                      UnknownData_BH42[0xF8]; // 0x00F8

			std::string ClassType()
			{
				std::string ClassType{};
				std::string FullName = this->GetFullName();
				for (int i = 0; i < FullName.size(); i++)
				{
					if (FullName[i] == ' ') break;
					ClassType.push_back(FullName[i]);
				}
				std::vector<std::string> ClassTypes = { "BoolProperty", "IntProperty", "FloatProperty", "NameProperty", "ByteProperty" };
				std::vector<std::string> FixedTypes = { "bool", "uint32_t", "float", "FName", "unsigned char" };
				for (int i = 0; i < ClassTypes.size(); i++)
				{
					if (ClassType == ClassTypes[i]) return FixedTypes[i];
				}
			}
		};
	}
}