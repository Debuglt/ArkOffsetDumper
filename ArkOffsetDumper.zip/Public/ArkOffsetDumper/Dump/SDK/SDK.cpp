#include "SDK.h"

bool SDK::InitSDK(const std::string& ModuleName, const uintptr_t GObjectsOffset, const uintptr_t GNamesOffset)
{
	auto BaseAddress = reinterpret_cast<uintptr_t>(GetModuleHandleA(ModuleName.c_str()));
	if (BaseAddress == 0x00) return false;
	SDK::Engine::UObject::GObjects = reinterpret_cast<decltype(SDK::Engine::UObject::GObjects)>(BaseAddress + GObjectsOffset);
	SDK::Engine::FName::GNames = *reinterpret_cast<decltype(SDK::Engine::FName::GNames)*>(BaseAddress + GNamesOffset);
	return true;
}

bool SDK::InitSDK()
{
	return InitSDK("ShooterGame.exe", GObjects_Offset, GNames_Offset);
}

void SDK::CleanupSDK()
{
	SDK::Engine::UObject::GObjects = nullptr;
	SDK::Engine::FName::GNames = nullptr;
}

std::string SDK::Engine::UObject::GetName() const
{
	std::string name(Name.GetName());
	if (Name.Number > 0) name += '_' + std::to_string(Name.Number);
	auto pos = name.rfind('/');
	if (pos == std::string::npos) return name;
	return name.substr(pos + 1);
}

std::string SDK::Engine::UObject::GetFullName() const
{
	std::string Name;
	if (Class != nullptr)
	{
		std::string Temp;
		for (auto p = Outer; p; p = p->Outer) Temp = p->GetName() + "." + Temp;
		Name = Class->GetName();
		Name += " ";
		Name += Temp;
		Name += GetName();
	}
	return Name;
}

bool SDK::Engine::UObject::IsA(UClass* cmp) const
{
	for (auto super = Class; super; super = static_cast<UClass*>(super->SuperField))
	{
		if (super == cmp) return true;
	}
	return false;
}