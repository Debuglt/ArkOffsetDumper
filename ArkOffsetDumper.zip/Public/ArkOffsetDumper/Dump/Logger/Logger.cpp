#include "Logger.h"

void Logger::Print(const char* format, ...)
{
    char Buf[MAX_PATH];
    va_list ArgPtr;
    va_start(ArgPtr, format);
    auto Size = vsnprintf(Buf, sizeof(Buf), format, ArgPtr);
    WriteFile(File2, Buf, Size, NULL, NULL);
    va_end(ArgPtr);
}

void Logger::Log(const char* format, ...)
{
    SYSTEMTIME RawTime;
    GetSystemTime(&RawTime);
    char Buf[MAX_PATH];
    auto Size = GetTimeFormatA(LOCALE_CUSTOM_DEFAULT, 0, &RawTime, "[HH':'mm':'ss] ", Buf, MAX_PATH) - 1;
    Size += snprintf(Buf + Size, sizeof(Buf) - Size, "[TID: 0x%X] ", GetCurrentThreadId());
    va_list ArgPtr;
    va_start(ArgPtr, format);
    Size += vsnprintf(Buf + Size, sizeof(Buf) - Size, format, ArgPtr);
    WriteFile(File, Buf, Size, NULL, NULL);
    va_end(ArgPtr);
}

bool Logger::Remove()
{
    if (!File && !File2) return true;
    if (File2) CloseHandle(File2);
    return CloseHandle(File);
}

bool Logger::Init()
{
    std::wstring FilePath(L"E:\\WpSystem\\S-1-5-21-4079962163-1231189451-3896316275-1001\\AppData\\Local\\Packages\\StudioWildcard.4558480580BB9_1w2mm55455e38\\TempState\\" + Logger::OutputFilename);
    std::wstring FilePath2(L"E:\\WpSystem\\S-1-5-21-4079962163-1231189451-3896316275-1001\\AppData\\Local\\Packages\\StudioWildcard.4558480580BB9_1w2mm55455e38\\TempState\\" + Logger::OutputFilename2);
    File = CreateFileW(FilePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    File2 = CreateFileW(FilePath2.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    return File != INVALID_HANDLE_VALUE && File2 != INVALID_HANDLE_VALUE;
}