#include "Logger.h"

void Logger::Print(const char* format, ...)
{
    char Buf[MAX_PATH];
    va_list ArgPtr;
    va_start(ArgPtr, format);
    auto Size = vsnprintf(Buf, sizeof(Buf), format, ArgPtr);
    WriteFile(File2, Buf, Size, NULL, NULL);
    va_end(ArgPtr);
}

void Logger::Log(const char* format, ...)
{
    SYSTEMTIME RawTime;
    GetSystemTime(&RawTime);
    char Buf[MAX_PATH];
    auto Size = GetTimeFormatA(LOCALE_CUSTOM_DEFAULT, 0, &RawTime, "[HH':'mm':'ss] ", Buf, MAX_PATH) - 1;
    Size += snprintf(Buf + Size, sizeof(Buf) - Size, "[TID: 0x%X] ", GetCurrentThreadId());
    va_list ArgPtr;
    va_start(ArgPtr, format);
    Size += vsnprintf(Buf + Size, sizeof(Buf) - Size, format, ArgPtr);
    WriteFile(File, Buf, Size, NULL, NULL);
    va_end(ArgPtr);
}

bool Logger::Remove()
{
    if (!File && !File2) return true;
    if (File2) CloseHandle(File2);
    return CloseHandle(File);
}

bool Logger::Init()
{
    std::wstring FilePath(OutputFilePath + OutputDebugFileName);
    std::wstring File2Path(OutputFilePath + OutputFileName);
    File = CreateFileW(FilePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    File2 = CreateFileW(File2Path.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    return File != INVALID_HANDLE_VALUE && File2 != INVALID_HANDLE_VALUE;
}