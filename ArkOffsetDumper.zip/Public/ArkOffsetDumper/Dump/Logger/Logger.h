#pragma once
#include <Windows.h>
#include <string>
#include <sstream>
#include <fstream>
#include <iostream>

#define OutputDebugFileName std::wstring(L"OffsetDumper.txt")
#define OutputFileName std::wstring(L"ClassDump.txt")
static std::wstring OutputPCUser = L"MyPCUsername";
static const std::wstring OutputFilePath = std::wstring(L"C:\\Users\\") + std::wstring(OutputPCUser) + std::wstring(L"\\AppData\\Local\\Packages\\StudioWildcard.4558480580BB9_1w2mm55455e38\\TempState\\");

class Logger
{
public:
    static inline HANDLE File;
    static inline HANDLE File2;
    static inline std::wstring OutputFilename = L"OffsetDumper.txt";
    static inline std::wstring OutputFilename2 = L"ClassDump.txt";
    static bool Init();
    static bool Remove();
    static void Print(const char* format, ...);
    static void Log(const char* Format, ...);
};