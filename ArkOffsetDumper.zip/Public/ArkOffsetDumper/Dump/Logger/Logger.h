#pragma once
#include <Windows.h>
#include <string>
#include <sstream>
#include <fstream>
#include <iostream>

class Logger
{
public:
    static inline HANDLE File;
    static inline HANDLE File2;
    static inline std::wstring OutputFilename = L"OffsetDumper.txt";
    static inline std::wstring OutputFilename2 = L"ClassDump.txt";
    static bool Init();
    static bool Remove();
    static void Print(const char* format, ...);
    static void Log(const char* Format, ...);
};